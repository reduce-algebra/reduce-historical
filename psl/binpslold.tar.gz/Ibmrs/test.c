#include <stdio.h>

int hugo = 16;

up(a1,a2,a3,a4,a5,a6)

int a1,a2,a3,a4,a5,a6;

{ return (a1+a2+a3+a4+a5+a6 + hugo); }

down()

{ hugo = 17; }


