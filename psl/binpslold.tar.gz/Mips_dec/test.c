#include <stdio.h>

up(a1,a2,a3,a4,a5,a6)

int a1,a2,a3,a4,a5,a6;

{ return (a1+a2+a3+a4+a5+a6); }


